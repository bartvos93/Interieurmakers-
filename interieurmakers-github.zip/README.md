# Interieurmakers werkplaats

Zaagplanner en rekenhulpen (schuine snede, groef, reeks groeven, kantband en vormen) in één pagina.

Open de app via GitHub Pages en zet hem op je beginscherm (Safari: Deel → Zet op beginscherm).
Projecten worden bewaard in de browser van het apparaat waarop je ze opslaat.
